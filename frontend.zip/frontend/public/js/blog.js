import { getArticleDetails } from "./funcs/shared.js";

window.addEventListener("load", () => {
    getArticleDetails();
});