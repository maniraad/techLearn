import { getAdminInfos } from "./func/utils.js";
import { getRecentlyUser } from "./func/shared.js";

window.addEventListener('load', () => {
    // Select Element From Dom
    const adminWelcomeElem = document.querySelector('.admin-welcome-name');
    getRecentlyUser()
    // Admin Info
    getAdminInfos().then(admin => {
        // Show Admin Name
        adminWelcomeElem.innerHTML = `خوش آمدید , ${admin.name}`

    });








    const pieChart = document.getElementById('pie-chart');
    const linearChart = document.getElementById('linear-chart');

    new Chart(pieChart, {
        type: 'doughnut',
        data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                label: '# of Votes',
                data: [12, 19, 3, 5, 2, 3],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Chart.js Doughnut Chart'
                }
            }
        },
    });

    new Chart(linearChart, {
        type: 'line',
        data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                label: '# of Votes',
                data: [12, 19, 3, 5, 2, 3],
                borderWidth: 1
            }, {
                label: '# of Votes',
                data: [2, 29, 5, 1, 8, 3],
                borderWidth: 1
            },
            ],

        },
        options: {
            animations: {
                radius: {
                    duration: 400,
                    easing: 'linear',
                    loop: (context) => context.active
                }
            },
            hoverRadius: 12,
            hoverBackgroundColor: 'yellow',
            interaction: {
                mode: 'nearest',
                intersect: false,
                axis: 'x'
            },
            plugins: {
                tooltip: {
                    enabled: false
                }
            }
        },
    });

    // const config = {
    //     type: 'line',
    //     data: data,
    //     options: {
    //       animations: {
    //         radius: {
    //           duration: 400,
    //           easing: 'linear',
    //           loop: (context) => context.active
    //         }
    //       },
    //       hoverRadius: 12,
    //       hoverBackgroundColor: 'yellow',
    //       interaction: {
    //         mode: 'nearest',
    //         intersect: false,
    //         axis: 'x'
    //       },
    //       plugins: {
    //         tooltip: {
    //           enabled: false
    //         }
    //       }
    //     },
    //   };
});