import { getAndShowUseCourse } from "./func/shared.js";

window.addEventListener("load", () => {
    getAndShowUseCourse();
});